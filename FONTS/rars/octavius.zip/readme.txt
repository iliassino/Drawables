This font "Octavius" is created by Jack Oatley.
Co-member of Bitty/Brixdee on http://www.dafont.com/profile.php?user=764521

This font is inspired by the type in the game "The Settlers II", some characters are the originals and some have been edited or added. There are 2 versions here, a regualar one, and one with defined kerning to make the letters seem more "joined up".

It is 100% free to use, though credit is appreciated and it'd be cool to know where you used it. You must not claim it as your own.